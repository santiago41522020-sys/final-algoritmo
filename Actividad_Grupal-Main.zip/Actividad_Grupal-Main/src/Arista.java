public class Arista {

    Vertice origen;
    Vertice destino;
    int peso;

    public Arista(Vertice origen, int peso, Vertice destino) {
    this.origen = origen;
    this.destino = destino;
    this.peso = peso;
    
    }

}
