import java.util.LinkedList;
public class Grafo {
  
      LinkedList<Vertice> Vertices = new LinkedList<>();
    LinkedList<Arista> Aristas = new LinkedList<>();

      public void agregarVertice(Vertice vertice){
        Vertices.add(vertice);
      }
      public void agregarArista(Vertice origen, int peso, Vertice destino){
      Arista arista = new Arista(origen, peso, destino);
      Aristas.add(arista);
      }
      public void mostrarGrafo() {

    System.out.println("===== GRAFO PONDERADO =====");

    for (Arista arista : Aristas) {
        System.out.println(
            arista.origen.nombre + " ──(" +
            arista.peso + " km)──> " +
            arista.destino.nombre
        );
    }
}
    
    public static void main(String[] args) {

        Grafo grafo = new Grafo();
 
        Vertice Apartado = new Vertice("Apartadó");
        Vertice Carepa  = new Vertice("Carépa");
        Vertice Chigorodo  = new Vertice("Chigorodó");
        Vertice Mutata = new Vertice("Mutatá");
        Vertice Dabeiba  = new Vertice("Dabeiba");
        Vertice Uramita  = new Vertice("Uramita");
        Vertice Cañasgordas  = new Vertice("Cañasgordas");

        grafo.agregarVertice(Apartado);
        grafo.agregarVertice(Carepa);
        grafo.agregarVertice(Chigorodo);
        grafo.agregarVertice(Mutata);
        grafo.agregarVertice(Dabeiba);
        grafo.agregarVertice(Uramita);
        grafo.agregarVertice(Cañasgordas);


        grafo.agregarArista(Apartado,17, Carepa);
        grafo.agregarArista(Carepa, 11, Chigorodo);
        grafo.agregarArista(Chigorodo,66, Mutata);
        grafo.agregarArista(Mutata, 50, Dabeiba );
        grafo.agregarArista(Dabeiba,26, Uramita);
        grafo.agregarArista(Uramita, 25, Cañasgordas);

       grafo.mostrarGrafo();
    }
}